return {
    override_enabled = true,
    worldgen_preset = "DST_CAVE",
    settings_preset = "DST_CAVE",
    overrides = {
	    portalresurection = "always",
	    basicresource_regrowth = "always",
	    resettime = "none",
	    ghostsanitydrain = "none",
	},
}
