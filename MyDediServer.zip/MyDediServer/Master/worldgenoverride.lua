return {
    override_enabled = true,
    overrides = {
	    portalresurection = "always",
	    basicresource_regrowth = "always",
	    resettime = "none",
	    ghostsanitydrain = "none",
	},
}
